/*
Author: Edgaras Jurevicius
Date: 2023-04-11
Group: JNII22
Assigment: Ninth practical assigment (STL library)
Revision date 1: 2023-04-12
*/

#include <iostream>
#include "DecimalToBinary.h"
#include "PersonalSchedule.h"
#include "Average.h"

int main()
{
    DecimalToBinary con1(128);
    DecimalToBinary con2(-128);
    DecimalToBinary con3(0);
    DecimalToBinary con4(7);

    Average avg;

    PersonalSchedule psch;


}


