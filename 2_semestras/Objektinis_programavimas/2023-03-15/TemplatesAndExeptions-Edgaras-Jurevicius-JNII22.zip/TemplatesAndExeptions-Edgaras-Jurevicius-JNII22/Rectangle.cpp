/*
Author: Edgaras Jurevicius
Date: 2023-03-02
Group: JNII22
Assigment: Sixth practical assigment (Templates and Exceptions)
Revision date 1:
*/
