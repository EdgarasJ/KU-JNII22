/*
Author: Edgaras Jurevicius
Date: 2023-03-01
Group: JNII22
Assigment: Fifth practical assigment (Polymorphism)
Revision date 1: 2023-03-08
*/

#include "GeometrineFigura.h"
//setters
void GeometrineFigura::setArea(double _area) {
	area = _area;
}